package com.example.nurjanadmin.service.modul;

import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

public class MultipartFileConverter {
    public File convertToFile(MultipartFile multipartFile)  {
        File file;
        try {
            file = File.createTempFile("temp", null);
            multipartFile.transferTo(file);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return file;
    }

}
