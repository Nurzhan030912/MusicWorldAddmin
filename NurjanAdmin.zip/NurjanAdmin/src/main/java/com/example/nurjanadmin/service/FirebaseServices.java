package com.example.nurjanadmin.service;

import com.example.nurjanadmin.config.FirebaseConfig;
import com.example.nurjanadmin.entity.AdminValuesModel;
import com.google.firebase.database.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;


public class FirebaseServices extends FirebaseConfig {
    private DatabaseReference database;

    public FirebaseServices(String path) {
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        database = firebaseDatabase.getReference(path);
    }

    public void saveDate(AdminValuesModel adminValuesModel) {
        adminValuesModel.setKey(database.push().getKey());
        database.child(adminValuesModel.getKey()).setValueAsync(adminValuesModel);
    }

    public CompletableFuture<List<Object>> getOptionsFromFirebase() {
        List<Object> options = new ArrayList<>();
        CompletableFuture<List<Object>> future = new CompletableFuture<>();
        database.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Iterate through the child nodes to retrieve all values
                for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {
                    Object data = childSnapshot.getValue();

                    options.add(data);
                }
                future.complete(options);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle any errors
                future.completeExceptionally(databaseError.toException());
            }
        });

        return future;
    }

    public void deleteTargetValue(String targetValue) {
        Map<String, Object> update = new HashMap<>();
        update.put(targetValue, null);

        database.updateChildren(update, (databaseError, databaseReference) -> System.out.println("Deleted"));
    }
}
