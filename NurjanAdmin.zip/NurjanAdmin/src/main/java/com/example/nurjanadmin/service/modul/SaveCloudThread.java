package com.example.nurjanadmin.service.modul;

import com.example.nurjanadmin.entity.AdminValuesModel;
import com.example.nurjanadmin.service.CloudinaryService;
import com.example.nurjanadmin.service.FirebaseServices;
import org.springframework.web.multipart.MultipartFile;

public class SaveCloudThread extends Thread {
    private AdminValuesModel adminValuesModel;
    private CloudinaryService cloudinaryService;
    private MultipartFileConverter multipartFileConverter;
    private MultipartFile musicFile;
    private MultipartFile image;
    private FirebaseServices firebaseServices;

    public SaveCloudThread(AdminValuesModel adminValuesModel, CloudinaryService cloudinaryService,
                           MultipartFileConverter multipartFileConverter, MultipartFile musicFile, MultipartFile image,
                           FirebaseServices firebaseServices) {
        this.adminValuesModel = adminValuesModel;
        this.cloudinaryService = cloudinaryService;
        this.multipartFileConverter = multipartFileConverter;
        this.musicFile = musicFile;
        this.image = image;
        this.firebaseServices = firebaseServices;
    }

    public void run() {
        if (!musicFile.isEmpty()) {
            adminValuesModel.setMusic(cloudinaryService.uploadCloudinary(multipartFileConverter.convertToFile(musicFile)));
        }

        if (!image.isEmpty()) {
            adminValuesModel.setImage(cloudinaryService.uploadCloudinary(multipartFileConverter.convertToFile(image)));
        }
        firebaseServices.saveDate(adminValuesModel);
    }

}
