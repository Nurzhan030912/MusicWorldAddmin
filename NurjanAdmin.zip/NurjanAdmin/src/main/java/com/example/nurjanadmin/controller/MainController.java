package com.example.nurjanadmin.controller;

import com.example.nurjanadmin.entity.AdminValuesModel;
import com.example.nurjanadmin.service.CloudinaryService;
import com.example.nurjanadmin.service.FirebaseServices;
import com.example.nurjanadmin.service.modul.MultipartFileConverter;
import com.example.nurjanadmin.service.modul.SaveCloudThread;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Controller
public class MainController {
    private CloudinaryService cloudinaryService = new CloudinaryService();
    private MultipartFileConverter multipartFileConverter = new MultipartFileConverter();
    private FirebaseServices firebaseServices;

    @GetMapping("/")
    public String get(Model model) {
        firebaseServices = new FirebaseServices("Нац");
        CompletableFuture<List<Object>> experience = firebaseServices.getOptionsFromFirebase();
        try {
            CompletableFuture.allOf(experience).join();
            List<Object> experienceList = experience.get();

            for (int i = 0; i < experienceList.size(); i++) {
                System.out.println(experienceList.get(i).toString());
            }

            model.addAttribute("experienceList", experienceList);
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return "index";
    }

    @PostMapping("/")
    public String post(@RequestParam("music") MultipartFile musicFile,
                       @RequestParam("image") MultipartFile image,
                       @RequestParam("song_name") String songName,
                       @RequestParam("janr") String janr,
                       @RequestParam("autor") String autor,
                       @RequestParam("lyrics") String lyrics,
                       @RequestParam("history") String history) {
        AdminValuesModel adminValuesModel = new AdminValuesModel(songName, janr, autor, lyrics, history, false, "");
        firebaseServices = new FirebaseServices("Нац");

        if (!musicFile.isEmpty()) {
            SaveCloudThread saveCloudThread = new SaveCloudThread(adminValuesModel, cloudinaryService,
                    multipartFileConverter, musicFile, image, firebaseServices);
            saveCloudThread.start();
        }

        return "redirect:/";
    }

    @PostMapping ("/update")
    public String update(@RequestParam("update")String update){
        return "redirect:/";
    }

    @PostMapping ("/delete")
    public String delete(@RequestParam("delete")String delete){
        firebaseServices = new FirebaseServices("Нац");
        firebaseServices.deleteTargetValue(delete);
        return "redirect:/";
    }
}
